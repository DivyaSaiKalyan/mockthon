import { CacheManagerInterceptor } from './cache-manager.interceptor';

describe('CacheManagerInterceptor', () => {
  it('should be defined', () => {
    expect(new CacheManagerInterceptor()).toBeDefined();
  });
});
