/**This class is used to set the role in static variable */
export class GlobalAccess {
  /**static variable */
  static role = ' ';
}
