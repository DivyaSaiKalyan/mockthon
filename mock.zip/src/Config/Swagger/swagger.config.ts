import { SwaggerConfig } from './swagger.interface';
/**
 * This variable is used to configure the swagger related info
 */
export const SWAGGER_CONFIG: SwaggerConfig = {
  Title: 'MockThon',
  Description: 'all mockthon apis are avaliabale here',
  Version: '1.0',
  Tags: ['Template']
};
