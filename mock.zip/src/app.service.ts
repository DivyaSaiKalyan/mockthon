import { Injectable } from '@nestjs/common';

/**
 * This is dummy class
 */
@Injectable()
export class AppService {
  // getHello(): string {
  //   return 'Hello World!';
  // }
}
