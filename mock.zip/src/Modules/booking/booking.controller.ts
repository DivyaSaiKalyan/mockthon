import { Controller } from '@nestjs/common';

@Controller('booking')
export class BookingController {}
