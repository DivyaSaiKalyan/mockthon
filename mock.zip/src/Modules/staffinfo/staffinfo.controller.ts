import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { StaffinfoService } from './staffinfo.service';
import { staffInfoDto } from './dto/staff.dto';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('staff related')
@Controller('staffinfo')
export class StaffinfoController {
  constructor(private readonly staffinfoService: StaffinfoService) {}

  @Post('addStaff')
  async addStaff(@Body() data: staffInfoDto) {
    return await this.staffinfoService.addStaff(data);
  }

  @Get('getStaffBasedOnCategory/:category')
  async getStaffBasedOnCategory(@Param('category') category: string) {
    return this.staffinfoService.getStaffBasedOnCategory(category);
  }

  @Get('getByEmailAndCategory/:category/:email')
  async getByEmailAndCategory(
    @Param('category') category: string,
    @Param('email') email: string
  ) {
    return this.staffinfoService.getByEmailAndCategory(category, email);
  }
}
