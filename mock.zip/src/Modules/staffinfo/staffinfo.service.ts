import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { staffInfo } from './../../Entities/staff-info.entity';
import { staffInfoDto } from './dto/staff.dto';
import { StaffCategory } from './../../Entities/staffCategory.entity';
import { NotFound } from './../../Common/Filters/custom.exception';

@Injectable()
export class StaffinfoService {
  constructor(
    @InjectRepository(staffInfo)
    private readonly staffInfoRepository: Repository<staffInfo>,
    @InjectRepository(StaffCategory)
    private readonly staffCategoryRepository: Repository<StaffCategory>
  ) {}

  async addStaff(data: staffInfoDto) {
    const getCategory = await this.staffCategoryRepository.findOne({
      Categoryname: data.Categoryname
    });
    const staffinfo = new staffInfo();
    let staffCategory = new StaffCategory();
    if (!getCategory) {
      throw new NotFound();
    } else {
      staffCategory = getCategory;
      staffinfo.createdBy = data.firstname;
      staffinfo.staffcategory = staffCategory;
      staffinfo.category = data.Categoryname;
      const newData = Object.assign(staffinfo, data);
      return await this.staffInfoRepository.save(newData);
    }
  }

  async getStaffBasedOnCategory(category: string) {
    return await this.findBYCategory(category);
  }

  async getByEmailAndCategory(category: string, email: string) {
    const getData = await this.staffInfoRepository.findOne({
      category: category,
      emailid: email
    });
    if (!getData) {
      throw new NotFound();
    }
    return getData;
  }

  async findBYCategory(category: string) {
    const getCategory = await this.staffInfoRepository.find({
      category: category
    });
    if (!getCategory) {
      throw new NotFound();
    }
    return getCategory;
  }
}
