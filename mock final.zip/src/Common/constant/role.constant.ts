/**constant */
export const recption = 'Recptionist';

/**constant */
export const Admin = 'Admin';

/**constant */
export const Doctor = 'Doctor';
